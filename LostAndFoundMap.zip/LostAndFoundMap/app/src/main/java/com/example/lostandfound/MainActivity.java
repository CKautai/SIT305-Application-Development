package com.example.lostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.example.lostandfound.data.DatabaseHelper;
import com.example.lostandfound.util.Util;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Initialize the SDK
        Places.initialize(getApplicationContext(), "AIzaSyCepY43jfvfx1ZDmvcPzQx6Sfu_Dw02vjg");

        // Create a new PlacesClient instance
        PlacesClient placesClient = Places.createClient(this);

        Log.d("CREATE", "CREATE TABLE " + Util.TABLE_NAME + " (" +Util.ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "
                + Util.TYPE + " TEXT, "
                + Util.NAME + " TEXT, "
                + Util.PHONE + " TEXT, "
                + Util.DESCRIPTION + " TEXT, "
                + Util.DATE + " TEXT, "
                + Util.LOCATION + " TEXT)");
        Button createAdButton = findViewById(R.id.newAdButton);
        Button showAdButton = findViewById(R.id.showAdButton);
        Button showMapButton = findViewById(R.id.showMapButton);
        ListView itemListView = findViewById(R.id.itemListView);

        db = new DatabaseHelper(this);

        createAdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createAdIntent = new Intent(MainActivity.this, CreateAdActivity.class);
                startActivity(createAdIntent);
            }
        });

        showAdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent showAdIntent = new Intent(MainActivity.this, ShowAdActivity.class);
                startActivity(showAdIntent);
            }
        });

        showMapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent showMapIntent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(showMapIntent);
            }
        });
    }
}