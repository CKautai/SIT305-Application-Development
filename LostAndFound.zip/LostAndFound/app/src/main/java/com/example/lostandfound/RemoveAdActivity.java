package com.example.lostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lostandfound.data.DatabaseHelper;
import com.example.lostandfound.model.Item;

public class RemoveAdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_ad);
        DatabaseHelper db = new DatabaseHelper(RemoveAdActivity.this);
        int id = getIntent().getExtras().getInt("itemId")+1;

        Item item = db.fetchUser(id);


        TextView typeTextView = findViewById(R.id.typeTextView);
        TextView nameTextView = findViewById(R.id.nameTextView);
        TextView phoneTextView = findViewById(R.id.phoneTextView);
        TextView descriptionTextView = findViewById(R.id.descriptionTextView);
        TextView dateTextView = findViewById(R.id.dateTextView);
        TextView locationTextView = findViewById(R.id.locationTextView);
        Button deleteButton = findViewById(R.id.deleteButton);

        typeTextView.setText(item.getType());
        nameTextView.setText((item.getName()));
        phoneTextView.setText(item.getPhone());
        descriptionTextView.setText(item.getDescription());
        dateTextView.setText(item.getDate());
        locationTextView.setText(item.getLocation());


        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.deleteUser(id);
                db.reseedTable();

            }
        });
    }


}