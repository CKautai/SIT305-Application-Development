package com.example.lostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.lostandfound.data.DatabaseHelper;
import com.example.lostandfound.model.Item;

public class CreateAdActivity extends AppCompatActivity {
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_ad);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);


        EditText nameEditText = findViewById(R.id.nameEditText);
        EditText phoneEditText = findViewById(R.id.phoneEditText);
        EditText descriptionEditText = findViewById(R.id.descriptionEditText);
        EditText dateEditText = findViewById(R.id.dateEditText);
        EditText locationEditText = findViewById(R.id.locationEditText);
        Button saveButton = findViewById(R.id.deleteButton);

        db = new DatabaseHelper(this);


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioButton radioButton;
                int radioId = radioGroup.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);
                String type = radioButton.getText().toString();
                String name = nameEditText.getText().toString();
                String phone = phoneEditText.getText().toString();
                String description = descriptionEditText.getText().toString();
                String date = dateEditText.getText().toString();
                String location = locationEditText.getText().toString();

                long result = db.insertItem(new Item(type, name, phone,description,date,location));
                if (result > 0){
                    Toast.makeText(CreateAdActivity.this, "Item Registered successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(CreateAdActivity.this, "Item Register failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}