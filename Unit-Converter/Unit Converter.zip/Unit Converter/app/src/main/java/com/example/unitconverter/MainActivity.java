package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DecimalFormat twodec = new DecimalFormat(".00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton lengthBut = (ImageButton) findViewById(R.id.LengthButton);
        ImageButton tempBut = (ImageButton) findViewById(R.id.TempButton);
        ImageButton weightBut = (ImageButton) findViewById(R.id.WeightButton);
        Spinner spinner = (Spinner) findViewById(R.id.UnitSpinner);
        EditText inputValue = (EditText) findViewById(R.id.UnitInput);
        TextView outPutText1 = (TextView) findViewById(R.id.outputText1);
        TextView outPutText2 = (TextView) findViewById(R.id.outputText2);
        TextView outPutText3 = (TextView) findViewById(R.id.outputText3);
        TextView outPutTitle1 = (TextView) findViewById(R.id.outputTitle1);
        TextView outPutTitle2 = (TextView) findViewById(R.id.outputTitle2);
        TextView outPutTitle3 = (TextView) findViewById(R.id.outputTitle3);

        lengthBut.setImageDrawable((getDrawable(R.drawable.ruler)));
        tempBut.setImageDrawable((getDrawable(R.drawable.temp)));
        weightBut.setImageDrawable((getDrawable(R.drawable.scale)));

        Context context = getApplicationContext();
        CharSequence wrongIcon = "Please select the correct conversion icon";
        CharSequence noInput = "Please input a value";
        int duration = Toast.LENGTH_SHORT;

        Toast inputToast = Toast.makeText(context, noInput, duration);
        Toast iconToast = Toast.makeText(context, wrongIcon, duration);
        iconToast.show();
        ArrayList<String> unitList = new ArrayList<>();
        unitList.add("Meter");
        unitList.add("Celsius");
        unitList.add("Kilograms");

        ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,unitList);

        spinner.setAdapter(adapter);


        lengthBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(inputValue.getText())) {
                    inputToast.show();
                    return; // or break, continue, throw
                }
                String unit = spinner.getSelectedItem().toString();


                Float value = Float.parseFloat(inputValue.getText().toString());

                switch(unit) {
                    case "Meter":
                        //Centimeter
                        double centimeter = value *100;
                        outPutText1.setText(String.valueOf(twodec.format(centimeter)));
                        outPutTitle1.setText("Centimeters");

                        //Feet
                        double feet = value * 3.281;
                        outPutText2.setText(String.valueOf(twodec.format(feet)));
                        outPutTitle2.setText("Feet");

                        //Feet
                        double inch = value * 39.37;
                        outPutText3.setText(String.valueOf(twodec.format(inch)));
                        outPutTitle3.setText("Inches");

                        break;

                    case "Celsius" :
                    case "Kilograms":
                        iconToast.show();

                        break;

                }
            }
        });


        tempBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(inputValue.getText())) {
                    inputToast.show();
                    return; // or break, continue, throw
                }
                String unit = spinner.getSelectedItem().toString();


                Float value = Float.parseFloat(inputValue.getText().toString());

                switch(unit) {
                    case "Celsius":
                        //Farenheit
                        double fahrenheit = (value * 9/5) + 32;
                        outPutText1.setText(String.valueOf(twodec.format(fahrenheit)));
                        outPutTitle1.setText("Fahrenheit");

                        //Kelvin
                        double kelvin = value + 273.15;
                        outPutText2.setText(String.valueOf(twodec.format(kelvin)));
                        outPutTitle2.setText("Kelvin");

                        //Blank
                        outPutText3.setText("");
                        outPutTitle3.setText("");

                        break;

                    case "Meter" :
                    case "Kilograms":
                        iconToast.show();

                        break;

                }
            }
        });

        weightBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(inputValue.getText())) {
                    inputToast.show();
                    return; // or break, continue, throw
                }
                String unit = spinner.getSelectedItem().toString();


                Float value = Float.parseFloat(inputValue.getText().toString());

                switch(unit) {
                    case "Kilograms":
                        //Gram
                        double gram = value *100;
                        outPutText1.setText(String.valueOf(twodec.format(gram)));
                        outPutTitle1.setText("Grams");

                        //Ounce(Oz)
                        double ounce = value * 35.274;
                        outPutText2.setText(String.valueOf(twodec.format(ounce)));
                        outPutTitle2.setText("Ounce(Oz)");

                        //Pound(lb)
                        double pound = value * 2.205;
                        outPutText3.setText(String.valueOf(twodec.format(pound)));
                        outPutTitle3.setText("Pounds(lb)");

                        break;

                    case "Celsius" :
                    case "Meter":
                        iconToast.show();

                        break;

                }
            }
        });


    }



}
