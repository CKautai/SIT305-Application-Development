package com.example.studytimerapp;

import static android.os.SystemClock.uptimeMillis;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private Boolean resume = false;
    Handler handler;
    long tMilliSec,tStart,tBuff,tUpdate= 0L;
    int sec,min,milliSec;
    String chronText = "00:00:00";
    String name = "Task",output;
    Chronometer chronometer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = findViewById(R.id.chronometer);
        ImageButton startButton = findViewById(R.id.playButton);
        ImageButton pauseButton = findViewById(R.id.pauseButton);
        ImageButton stopButton = findViewById(R.id.stopButton);
        TextView historyText = findViewById(R.id.historyView);
        EditText nameInput = findViewById(R.id.nameInput);

        handler = new Handler();

        if(savedInstanceState !=null) {
            chronText = savedInstanceState.getString("chronText");
            tMilliSec = savedInstanceState.getLong("tMilliSec");
            tStart = savedInstanceState.getLong("tStart");
            tBuff = savedInstanceState.getLong("tBuff");
            tUpdate = savedInstanceState.getLong("tUpdate");
            sec = savedInstanceState.getInt("sec");
            min = savedInstanceState.getInt("min");
            milliSec = savedInstanceState.getInt("milliSec");
            resume = savedInstanceState.getBoolean("resume");
            output = savedInstanceState.getString("output");
            name = savedInstanceState.getString("name");

            nameInput.setText(name);
            historyText.setText(output);


        }
        chronometer.setText(chronText);
        if(resume){
            tBuff += tMilliSec;
            handler.removeCallbacks(runnable);
            chronometer.stop();
            resume = false;
            tStart = SystemClock.uptimeMillis();
            handler.postDelayed(runnable,0);
            chronometer.start();
            resume = true;
        }


        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!resume){
                    tStart = SystemClock.uptimeMillis();
                    handler.postDelayed(runnable,0);
                    chronometer.start();
                    resume = true;


                }
            }
        });

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(resume) {
                    tBuff += tMilliSec;
                    handler.removeCallbacks(runnable);
                    chronometer.stop();
                    resume = false;
                }

            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(! resume){
                    name = nameInput.getText().toString();
                    output = "You spent "+ chronText +" on "+ name;
                    historyText.setText(output);

                    tMilliSec = 0L;
                    tStart = 0L;
                    tBuff = 0L;
                    tUpdate = 0L;
                    sec = 0;
                    min = 0;
                    milliSec = 0;
                    chronometer.setText("00:00:00");
                }

            }
        });
    }
    public Runnable runnable = new Runnable() {
        @Override
        public void run() {
            tMilliSec = SystemClock.uptimeMillis() - tStart;
            tUpdate = tBuff + tMilliSec;
            sec = (int) (tUpdate/1000);
            min = sec/60;
            sec = sec%60;
            milliSec = (int) (tUpdate%100);
            chronometer.setText(String.format("%02d",min)+":"+String.format("%02d",sec)+":"+String.format("%02d",milliSec));
            chronText = chronometer.getText().toString();
            handler.postDelayed(this,60);
        }
    };

    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        chronText = chronometer.getText().toString();
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("chronText",chronText);
        savedInstanceState.putString("output", output);
        savedInstanceState.putString("name",name);
        savedInstanceState.putLong("tMilliSec",tMilliSec);
        savedInstanceState.putLong("tStart",tStart);
        savedInstanceState.putLong("tBuff",tBuff);
        savedInstanceState.putLong("tUpdate",tUpdate);
        savedInstanceState.putInt("sec",sec);
        savedInstanceState.putInt("min",min);
        savedInstanceState.putInt("milliSec",milliSec);
        savedInstanceState.putBoolean("resume", resume);

    }

}