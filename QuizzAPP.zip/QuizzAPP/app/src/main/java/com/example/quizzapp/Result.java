package com.example.quizzapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Result extends AppCompatActivity {
    String name;
    Integer score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        TextView congratText = findViewById(R.id.congratText);
        TextView scoreText = findViewById(R.id.scoreText);
        Button newQuizButton = findViewById(R.id.newQuizButton);
        Button finish = findViewById(R.id.finishButton);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        name = extras.getString("NAME");
        score = extras.getInt("SCORE");

        congratText.setText("Congratulations " +name+"!");
        scoreText.setText(score.toString()+"/5");

        newQuizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(view.getContext(), MainActivity.class);
                intent2.putExtra("NAME", name);
                startActivity(intent2);

            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);
            }
        });

    }
}