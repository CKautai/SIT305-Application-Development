package com.example.quizzapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class Questions extends AppCompatActivity {
    Integer questionNo = 1;
    Boolean correct = false;
    Integer score = 0;
    Integer selected = 0;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);
        TextView questionTitle = findViewById(R.id.questionTitle);
        TextView questionBody = findViewById(R.id.questionBody);
        TextView welcomeName = findViewById(R.id.welcomeName);
        TextView questionNumView  =findViewById(R.id.questionNumView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);


        Intent intent = getIntent();
        name = intent.getStringExtra("NAME_DATA");
        welcomeName.setText("Welcome "+ name);
        Question1();


    }

    public void Question1(){
        TextView questionTitle = findViewById(R.id.questionTitle);
        TextView questionBody = findViewById(R.id.questionBody);
        TextView welcomeName = findViewById(R.id.welcomeName);
        TextView questionNumView  =findViewById(R.id.questionNumView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);

        questionNumView.setText(questionNo.toString() + "/5");
        progressBar.setProgress(questionNo);
        correct = false;
        questionTitle.setText("What does a button do?");
        questionBody.setText("Choose the correct answer below");
        answer1.setText("Show Progress");
        answer2.setText("Whatever you program it to do");
        answer3.setText("Display text");
        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 1;
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = true;
                selected = 2;
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 3;
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkNullAnswer()) {
                    if (correct == false) {
                        if (selected == 1) {
                            answer1.setBackgroundColor(Color.RED);
                        }
                        if (selected == 2) {
                            answer2.setBackgroundColor(Color.RED);
                        }
                        if (selected == 3) {
                            answer3.setBackgroundColor(Color.RED);
                        }
                        answer2.setBackgroundColor(Color.GREEN);
                    } else {
                        answer2.setBackgroundColor(Color.GREEN);
                        score += 1;
                    }

                    submit.setVisibility(View.GONE);
                    next.setVisibility(View.VISIBLE);
                }
            }

        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
                questionNo +=1;
                progressBar.setProgress(questionNo);
                Question2();
            }
        });
    }
    public void Question2(){
        TextView questionTitle = findViewById(R.id.questionTitle);
        TextView questionBody = findViewById(R.id.questionBody);
        TextView welcomeName = findViewById(R.id.welcomeName);
        TextView questionNumView  =findViewById(R.id.questionNumView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);
        questionNumView.setText(questionNo.toString() + "/5");
        progressBar.setProgress(questionNo);
        correct = false;
        questionTitle.setText("What does a progress bar show?");
        questionBody.setText("Choose the correct answer below");
        answer1.setText("Progress");
        answer2.setText("Text");
        answer3.setText("Images");
        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = true;
                selected = 1;
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 2;
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 3;
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkNullAnswer()) {
                    if (correct == false) {
                        if (selected == 1) {
                            answer1.setBackgroundColor(Color.RED);
                        }
                        if (selected == 2) {
                            answer2.setBackgroundColor(Color.RED);
                        }
                        if (selected == 3) {
                            answer3.setBackgroundColor(Color.RED);
                        }
                        answer1.setBackgroundColor(Color.GREEN);
                    } else {
                        answer1.setBackgroundColor(Color.GREEN);
                        score += 1;
                    }

                    submit.setVisibility(View.GONE);
                    next.setVisibility(View.VISIBLE);
                }
            }

        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
                questionNo +=1;
                progressBar.setProgress(questionNo);
                Question3();
            }
        });

    }
    public void Question3(){
        TextView questionTitle = findViewById(R.id.questionTitle);
        TextView questionBody = findViewById(R.id.questionBody);
        TextView welcomeName = findViewById(R.id.welcomeName);
        TextView questionNumView  =findViewById(R.id.questionNumView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);
        questionNumView.setText(questionNo.toString() + "/5");
        progressBar.setProgress(questionNo);
        correct = false;
        questionTitle.setText("Which language is used in Android Studio?");
        questionBody.setText("Choose the correct answer below");
        answer1.setText("Java");
        answer2.setText("C++");
        answer3.setText("Python");
        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = true;
                selected = 1;
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 2;
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 3;
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkNullAnswer()) {
                    if (correct == false) {
                        if (selected == 1) {
                            answer1.setBackgroundColor(Color.RED);
                        }
                        if (selected == 2) {
                            answer2.setBackgroundColor(Color.RED);
                        }
                        if (selected == 3) {
                            answer3.setBackgroundColor(Color.RED);
                        }
                        answer1.setBackgroundColor(Color.GREEN);
                    } else {
                        answer1.setBackgroundColor(Color.GREEN);
                        score += 1;
                    }

                    submit.setVisibility(View.GONE);
                    next.setVisibility(View.VISIBLE);
                }
            }

        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
                questionNo +=1;
                progressBar.setProgress(questionNo);
                Question4();
            }
        });

    }
    public void Question4(){
        TextView questionTitle = findViewById(R.id.questionTitle);
        TextView questionBody = findViewById(R.id.questionBody);
        TextView welcomeName = findViewById(R.id.welcomeName);
        TextView questionNumView  =findViewById(R.id.questionNumView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);
        questionNumView.setText(questionNo.toString() + "/5");
        progressBar.setProgress(questionNo);
        correct = false;
        questionTitle.setText("Which is used to represent basic text?");
        questionBody.setText("Choose the correct answer below");
        answer1.setText("Double");
        answer2.setText("Integers");
        answer3.setText("String");
        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 1;
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 2;
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = true;
                selected = 3;
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkNullAnswer()) {
                    if (correct == false) {
                        if (selected == 1) {
                            answer1.setBackgroundColor(Color.RED);
                        }
                        if (selected == 2) {
                            answer2.setBackgroundColor(Color.RED);
                        }
                        if (selected == 3) {
                            answer3.setBackgroundColor(Color.RED);
                        }
                        answer3.setBackgroundColor(Color.GREEN);
                    } else {
                        answer3.setBackgroundColor(Color.GREEN);
                        score += 1;
                    }

                    submit.setVisibility(View.GONE);
                    next.setVisibility(View.VISIBLE);
                }
            }

        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                refresh();
                questionNo +=1;
                progressBar.setProgress(questionNo);
                Question5();
            }
        });

    }
    public void Question5(){
        TextView questionTitle = findViewById(R.id.questionTitle);
        TextView questionBody = findViewById(R.id.questionBody);
        TextView welcomeName = findViewById(R.id.welcomeName);
        TextView questionNumView  =findViewById(R.id.questionNumView);
        ProgressBar progressBar = findViewById(R.id.progressBar);
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);
        questionNumView.setText(questionNo.toString() + "/5");
        progressBar.setProgress(questionNo);
        correct = false;
        questionTitle.setText("Which of these is used to represent true or false?");
        questionBody.setText("Choose the correct answer below");
        answer1.setText("String");
        answer2.setText("Boolean");
        answer3.setText("Decimal");
        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 1;
            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = true;
                selected = 2;
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                correct = false;
                selected = 3;
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkNullAnswer()) {
                    if (correct == false) {
                        if (selected == 1) {
                            answer1.setBackgroundColor(Color.RED);
                        }
                        if (selected == 2) {
                            answer2.setBackgroundColor(Color.RED);
                        }
                        if (selected == 3) {
                            answer3.setBackgroundColor(Color.RED);
                        }
                        answer2.setBackgroundColor(Color.GREEN);
                    } else {
                        answer2.setBackgroundColor(Color.GREEN);
                        score += 1;
                    }

                    submit.setVisibility(View.GONE);
                    next.setVisibility(View.VISIBLE);
                }
            }

        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent3 = new Intent(view.getContext(), Result.class);
                Bundle extras = new Bundle();
                extras.putString("NAME", name);
                extras.putInt("SCORE", score);
                intent3.putExtras(extras);
                startActivity(intent3);
            }
        });

    }
    public void refresh(){
        Button answer1 = findViewById(R.id.answer1);
        Button answer2 = findViewById(R.id.answer2);
        Button answer3 = findViewById(R.id.answer3);
        Button submit = findViewById(R.id.submitButton);
        Button next = findViewById(R.id.nextButton);

        answer1.setBackgroundColor(Color.rgb(98, 0, 238));
        answer2.setBackgroundColor(Color.rgb(98, 0, 238));
        answer3.setBackgroundColor(Color.rgb(98, 0, 238));
        selected = 0;
        submit.setVisibility(View.VISIBLE);
        next.setVisibility(View.GONE);
    }

    public Boolean checkNullAnswer(){
        if(selected == 0) {
            Toast.makeText(getApplicationContext(), "Please select an answer", Toast.LENGTH_SHORT).show();
            return false;
        }else{
            return true;
        }
    }
}